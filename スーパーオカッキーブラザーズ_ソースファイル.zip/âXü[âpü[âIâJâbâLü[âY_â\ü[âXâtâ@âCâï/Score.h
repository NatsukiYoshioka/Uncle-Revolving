#pragma once
#include"DxLib.h"

class Player;
class Score
{
public:
	Score();
	~Score();

	void fontLoad();
	void fontChange();
	void GetScore(Player* player);
	void Draw();
	float GetScore() { return score; }
private:
	LPCSTR scoreFontPath;
	int FontHandle;

	int scoreStringWidth;
	float score;
};

