#pragma once
#include"SceneManager.h"
#include"DxLib.h"

class SceneManager;

class menuScene
{
public:
	menuScene();
	~menuScene();
	
	void Update(SceneManager* manager);
	void Draw();
private:
	int FontHandle;
};

