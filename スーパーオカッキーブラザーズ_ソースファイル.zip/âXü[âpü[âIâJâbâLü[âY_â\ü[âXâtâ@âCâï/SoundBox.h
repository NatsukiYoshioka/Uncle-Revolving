#pragma once

class SoundBox
{
private:


	int GameStartSHandle;
	int TitleSHandle;
	int ResultSHandle;
	int SwingSHandle;
	int HammerSelectSHandle;
	int RotateSHandle;
	int LandingSHandle;
	int FlightSHandle;
	int GameSelectSHandle;
	int GameBGMSHandle;
	int UFOSHandle;
	int ScreamSHandle;

public:
	SoundBox(void);	//�T�E���h���������ɓǂݍ���
	~SoundBox(void);
	//�Đ�
	static void play(int snum);
	//�Đ��i���[�v�j
	static void playloop(int snum);

	//��~
	static void stop(int snum);	

	//�T�E���h�f�[�^������������폜
	static void del(int snum);

	int GetGameStartSHandle()
	{
		return GameStartSHandle;
	}
	int GetTitleSHandle()
	{ 
		return TitleSHandle;
	}
	int GetResultSHandle()
	{ 
		return ResultSHandle;
	}
	int GetSwingSHandle()
	{
		return SwingSHandle;
	}
	int GetHammerSelectSHandle()
	{
		return HammerSelectSHandle;
	}
	int GetRotateSHandle()
	{
		return RotateSHandle;
	}
	int GetLandingSHandle()
	{
		return LandingSHandle;
	}
	int GetFlightSHandle()
	{
		return FlightSHandle;
	}
	int GetGameSelectSHandle()
	{
		return GameSelectSHandle;
	}
	int GetGameBGMSHandle()
	{
		return GameBGMSHandle;
	}
	int GetUFOSHandle()
	{
		return UFOSHandle;
	}
	int GetScreamSHandle()
	{
		return ScreamSHandle;
	}

	bool IsHammerSelect = false;
};

