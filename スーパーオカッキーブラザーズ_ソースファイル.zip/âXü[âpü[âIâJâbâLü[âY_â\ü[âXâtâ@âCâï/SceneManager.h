#pragma once
#include"menuScene.h"
#include"ShotPutter.h"
#include"resultScene.h"

#define SCENE_MENU		1
#define SCENE_GAME		2
#define SCENE_RESULT	3

#define SCENE_NONE		0

class menuScene;
class ShotPutter;
class resultScene;
class Player;
class SoundBox;

class SceneManager
{
public:
	SceneManager();
	~SceneManager();

	void Update(SceneManager* manager);
	void Init();
	void InitializeModule(int Scene);
	void Finalize();
	void FinalizeModule(int Scene);
	void Draw();
	void ChangeScene(int NextScene);
private:
	menuScene* MenuScene;
	ShotPutter* GameScene;
	resultScene* ResultScene;
	Player* player;
	SoundBox* sound;

	int nowScene;
	int nextScene;

	float score;
};

