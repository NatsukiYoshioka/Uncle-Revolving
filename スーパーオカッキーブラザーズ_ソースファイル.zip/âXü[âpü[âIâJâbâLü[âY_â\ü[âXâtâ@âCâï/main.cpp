﻿//-----------------------------------------------------------------------------
// @brief  メイン処理.
// 2016 Takeru Yui All Rights Reserved.
//-----------------------------------------------------------------------------
#include"DxLib.h"
#include"FpsController.h"
#include"sceneManager.h"

// 障害物の数.
#define OBSTRUCT_NUM 3

//-----------------------------------------------------------------------------
// @brief  メイン関数.
//-----------------------------------------------------------------------------
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) 
{
	// ＤＸライブラリ初期化処理
	if (DxLib_Init() == -1)		
	{
		return -1;	// エラーが起きたら直ちに終了
	}

	// 画面モードのセット
	SetGraphMode(1920, 1080, 16);
	ChangeWindowMode(FALSE);
	SetFontSize(20);
	SetWaitVSyncFlag(0);
	SetMouseDispFlag(TRUE);

	FpsController FpsControll;
	SceneManager* sceneManager = new SceneManager();

	sceneManager->Init();
	// エスケープキーが押されるかウインドウが閉じられるまでループ
	while (ProcessMessage() == 0 && CheckHitKey(KEY_INPUT_ESCAPE) == 0)
	{
		//画面初期化
		ClearDrawScreen();

		//フレームレート制御
		FpsControll.Update();

		//ゲーム処理
		sceneManager->Update(sceneManager);

		//ゲームシーン描画
		sceneManager->Draw();

		//フレームレート表示
		FpsControll.Draw();

		//待機
		FpsControll.Wait();

		// 裏画面の内容を表画面に反映させる
		ScreenFlip();
	}

	sceneManager->Finalize();
	delete(sceneManager);

	// ＤＸライブラリの後始末
	DxLib_End();

	// ソフトの終了
	return 0;
}