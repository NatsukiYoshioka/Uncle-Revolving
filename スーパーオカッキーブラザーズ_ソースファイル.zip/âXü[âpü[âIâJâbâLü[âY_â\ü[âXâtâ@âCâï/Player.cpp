﻿//-----------------------------------------------------------------------------
// @brief  プレイヤークラス.
// 2016 Takeru Yui All Rights Reserved.
//-----------------------------------------------------------------------------
#include "Player.h"
#include"SoundBox.h"
#include"math.h"

//-----------------------------------------------------------------------------
// @brief  コンストラクタ.
//-----------------------------------------------------------------------------
Player::Player()
{
	// ３Ｄモデルの読み込み
	/*modelHandle = MV1LoadModel("data/model/player/hackadoll.pmx");*/
	modelHandle = MV1LoadModel("data/model/Nonentity_uncle/uncle.pmd");
	//MV1SetScale(modelHandle, VGet(15.0f, 15.0f, 15.0f));
	hammerModelHandle = MV1LoadModel("data/model/hammer.x");
	MV1SetScale(hammerModelHandle, VGet(10.0f, 10.0f, 10.0f));
	MV1SetRotationXYZ(hammerModelHandle, VGet(1.5f, 0.0f, 1.5f));
	hammerPos = VGet(0.0f, 3.0f, -20.0f);

	pos = VGet(0, 0, 0);
}

//-----------------------------------------------------------------------------
// @brief  デストラクタ.
//-----------------------------------------------------------------------------
Player::~Player()
{
	// モデルのアンロード.
	MV1DeleteModel(modelHandle);
	MV1DeleteModel(hammerModelHandle);
	DeleteFontToHandle(FontHandle);
}

//-----------------------------------------------------------------------------
// @brief  更新.
//-----------------------------------------------------------------------------
void Player::Update(SoundBox* sound)
{
	Spin(sound);
	if (spinCount >= 1)
	{
		spinSpeed = 0.01f;
	}
	if (spinCount >= 10)
	{
		spinSpeed = 0.03f;
	}
	if (spinCount >= 20)
	{
		spinSpeed = 0.05f;
	}
	if (spinCount >= 30)
	{
		spinSpeed = 0.07f;
	}
	if (spinCount >= 40)
	{
		spinSpeed = 0.1f;
	}
	if (spinCount >= 50)
	{
		spinSpeed = 0.25f;
	}
	if (spinCount >= 70)
	{
		spinSpeed = 0.35f;
	}
	if (spinCount >= 100)
	{
		spinSpeed = 0.5f;
	}
	radian -= spinSpeed;
	if (radian == 2 || radian == -2)
	{
		radian = 0;
	}
	MV1SetRotationXYZ(modelHandle, VGet(0.0f, DX_PI * radian, 0.0f));
	hammerSpin();
	// ３Dモデルのポジション設定
	MV1SetPosition(modelHandle, pos);
}

//-----------------------------------------------------------------------------
// @brief  描画.
//-----------------------------------------------------------------------------
void Player::Draw()
{
	// ３Ｄモデルの描画
	MV1DrawModel(modelHandle);
}

void Player::Spin(SoundBox* sound)
{
	
	
	int mouseX, mouseY;
	int i;
	if ((GetMouseInput() & MOUSE_INPUT_LEFT )!= 0)
	{
		if (!sound->IsHammerSelect)
		{
			//ハンマー選択
			sound->play(sound->GetHammerSelectSHandle());
			//マウス回転
			sound->playloop(sound->GetRotateSHandle());

			sound->IsHammerSelect = true;
		}
		timer += 1;
		hitMouseFlg = true;
		GetMousePoint(&mouseX, &mouseY);
		if (mouseX >= 0 && mouseY >= 0 && mouseX <= 960 && mouseY <= 540 && spinFlg[0] == false)
		{
			spinFlg[0] = true;
			flg += 1;
		}
		if (mouseX >= 0 && mouseY >= 540 && mouseX <= 960 && mouseY <= 1080 && spinFlg[1] == false)
		{
			spinFlg[1] = true;
			flg += 1;
		}
		if (mouseX >= 960 && mouseY >= 540 && mouseX <= 1920 && mouseY <= 1080 && spinFlg[2] == false)
		{
			spinFlg[2] = true;
			flg += 1;
		}
		if (mouseX >= 960 && mouseY >= 0 && mouseX <= 1920 && mouseY <= 540 && spinFlg[3] == false)
		{
			spinFlg[3] = true;
			flg += 1;
		}
		if (flg == 4)
		{
			spinCount += 1;
			for (i = 0; i < 4; i++)
			{
				spinFlg[i] = false;
			}
			flg = 0;
		}
	}
	if (hitMouseFlg == true && (GetMouseInput() & MOUSE_INPUT_LEFT) == 0)
	{
		endFlg = true;
		power = VGet(0, spinCount * 7, spinCount * 15);
		sound->stop(sound->GetRotateSHandle());
	}
	if (timer == 600)
	{
		endFlg = true;
		power = VGet(0,spinCount * 7, spinCount * 15);
		sound->stop(sound->GetRotateSHandle());
	}
}

void Player::Throw(Map* map)
{
	pos = map->GetPos();
	pos = VAdd(pos, power);
	map->SetPos(pos);
	//MV1SetPosition(modelHandle, pos);
	radian -= 0.25f;
	if (radian == 2 || radian == -2)
	{
		radian = 0;
	}
	if (power.y <= 0)
	{
		MV1SetRotationXYZ(modelHandle, VGet(1.5f, 0.0f, DX_PI * radian));
	}
	else
	{
		MV1SetRotationXYZ(modelHandle, VGet(-1.5f, 0.0f, DX_PI * radian));
	}
	distance += power.z;
	power = VAdd(power,VGet(0,-1,-1));
	if (pos.y <= 0)
	{
		endFlg = true;
	}
}

void Player::hammerSpin()
{
	RoatVec2(VGet(0, 0, -1));
	MV1SetPosition(hammerModelHandle,hammerPos);
}

void Player::RoatVec2(VECTOR rad)
{
	VECTOR vec = VGet(0, 0, 0);
	vec.x = (rad.x * cos(-radian * DX_PI)-rad.z*sin(-radian*DX_PI));
	vec.z = (rad.x * sin(-radian * DX_PI) + rad.z * cos(-radian * DX_PI));
	vec = VNorm(vec);

	int dis = 20;
	vec = VScale(vec, dis);
	hammerPos = VAdd(pos, vec);
	MV1SetRotationXYZ(hammerModelHandle, VGet(-1.5f, atan2(hammerPos.x, hammerPos.z), 0.0f));
}