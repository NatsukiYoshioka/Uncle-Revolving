#pragma once
#include<unordered_map>
#include"AnimationName.h"
namespace AnimationData
{
	std::unordered_map<AnimationName, const int>  ANIMATION_NUMBER =
	{
		{AnimationName::Idle,0},
		{AnimationName::Jump,1},
		{AnimationName::Spin,2},
		{AnimationName::anim1 ,3},
		{AnimationName::anim2,4},


	};
	std::unordered_map<AnimationName, const float>  ANIMATION_SPEED =
	{
		{AnimationName::Idle,1},
		{AnimationName::Jump,0.2f},
		{AnimationName::Spin,1.0f},
		{AnimationName::anim1 ,1.0f},
		{AnimationName::anim2 ,1.0f},

	
	};
}