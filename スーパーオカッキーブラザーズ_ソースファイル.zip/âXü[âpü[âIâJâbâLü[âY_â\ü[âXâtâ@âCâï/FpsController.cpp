#include "FpsController.h"
#include"DxLib.h"

FpsController::FpsController() :Count(0), Fps(0)
{
	startTime = GetNowCount();
}

void FpsController::Update()
{
	if (Count == 0)
	{
		startTime = GetNowCount();
	}
	if (Count == N)
	{
		int t = GetNowCount();
		Fps = 1000.0f / ((t - startTime) / (float)N);
		Count = 0;
		startTime = t;
	}
	Count++;
}

void FpsController::Draw()
{
	DrawFormatString(0, 0, GetColor(255, 255, 255), "%.1f", Fps);
}

void FpsController::Wait()
{
	int tookTime = GetNowCount() - startTime;
	int waitTime = Count * 1000 / FPS - tookTime;

	if (waitTime > 0)
	{
		Sleep(waitTime);
	}
}