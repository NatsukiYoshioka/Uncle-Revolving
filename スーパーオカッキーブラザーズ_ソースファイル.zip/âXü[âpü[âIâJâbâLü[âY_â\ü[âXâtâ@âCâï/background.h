#pragma once
#include"DxLib.h"

class Player;
class background
{
public:
	background();
	~background();

	void Update(Player* player);
	void Draw();
private:
	bool up = true;

	int water;
	int sky;
	int darksky;
	int space;

	int UFO;

	int cloud[4];

	float scroll;
};

