#include "background.h"
#include"DxLib.h"
#include"Player.h"

background::background():scroll(0.0f)
{
	//�w�i�摜�̃��[�h
	water = LoadGraph("data/background/sea.png");
	sky = LoadGraph("data/background/sky.png");
	darksky = LoadGraph("data/background/darksky.png");
	space = LoadGraph("data/background/space.png");

	cloud[0] = LoadGraph("data/background/C2010.png");
	cloud[1] = LoadGraph("data/background/C2011.png");
	cloud[2] = LoadGraph("data/background/C2012.png");
	cloud[3] = LoadGraph("data/background/C2013.png");

	UFO = LoadGraph("data/background/UFO.png");
}

background::~background()
{
	//�摜�̃A�����[�h
	DeleteGraph(water);
	DeleteGraph(sky);
	DeleteGraph(darksky);
	DeleteGraph(space);
	DeleteGraph(UFO);
}

//�w�i�X�N���[������
void background::Update(Player* player)
{
	float power = player->GetPowerY();
	if (scroll <= 5400&&up)
	{
		scroll += power / 5;
	}
	else
	{
		scroll -= 10.0f;
	}
	if (scroll >= 5400)
	{
		up = false;
	}
	if (scroll < 0)
	{
		scroll = 0;
	}
}

void background::Draw()
{
	//�w�i�`��
	DrawExtendGraph(0, 0 + static_cast<int>(scroll), 1920, 1080 + static_cast<int>(scroll), water, TRUE);
	DrawExtendGraph(0, -1080 + static_cast<int>(scroll), 1920, 0 + static_cast<int>(scroll), sky, TRUE);
	DrawExtendGraph(0, -1080 * 2 + static_cast<int>(scroll), 1920, -1080 + static_cast<int>(scroll), darksky, TRUE);
	for (int i = 0;i < 3;i++)
	{
		DrawExtendGraph(0, -1080 * (3 + i) + static_cast<int>(scroll), 1920, -1080 * (2 + i) + static_cast<int>(scroll), space, TRUE);
	}

	//�_�`��
	for (int i = 0;i < 12;i++)
	{
		DrawExtendGraph(i * 160, -1160 + static_cast<int>(scroll), 160 + i * 160, -1000 + static_cast<int>(scroll), cloud[i % 4], TRUE);
	}

	//UFO�`��
	DrawExtendGraph(1460, -3240 + static_cast<int>(scroll), 1760, -2940 + static_cast<int>(scroll), UFO, TRUE);
}
