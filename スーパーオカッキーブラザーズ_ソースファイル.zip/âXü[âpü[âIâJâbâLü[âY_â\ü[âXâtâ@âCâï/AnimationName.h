#pragma once
enum class AnimationName
{
	Idle,
	Jump,
	Spin,
	anim1,
	anim2,
};