#ifndef DEF_EFFECT_H
#define DEF_EFFECT_H
#include"DxLib.h"

int Effect_Initialize(VECTOR pos);
void Effect_Update(VECTOR pos, Player* player);
void Effect_Draw();
void Effect_Finalize();
#endif