﻿//-----------------------------------------------------------------------------
// @brief  プレイヤークラス.
// 2016 Takeru Yui All Rights Reserved.
//-----------------------------------------------------------------------------
#ifndef _PLAYER_H_
#define _PLAYER_H_

#include "DxLib.h"
#include"Map.h"

class SoundBox;
class Player final
{
public:
	Player();				// コンストラクタ.
	~Player();				// デストラクタ.

	void Update(SoundBox* sound);			// 更新.
	void Draw();			// 描画.
	void Spin(SoundBox* sound);			// 回転
	void Throw(Map* map);
	void hammerSpin();
	void RoatVec2(VECTOR rad);
	// モデルハンドルの取得.
	int GetModelHandle(){ return modelHandle; }

	int GetTimer() { return timer; }

	bool hitMouseFlg = false;
	bool endFlg = false;
	// ポジションのgetter/setter.
	const VECTOR& GetPos() const { return pos; }
	void SetPos(const VECTOR set) { pos = set; }

	int		modelHandle;	// モデルハンドル.
	int hammerModelHandle;

	float GetDistance() { return distance; }
	float GetPowerY() { return power.y; }
private:
	float distance = 0;
	
	VECTOR	pos;			// ポジション.
	VECTOR hammerPos;
	bool spinFlg[4] = {false};  //1周判定
	int spinCount = 0;
	float spinSpeed = 0;
	float radian = 0;
	int flg= 0;
	int timer = 0;
	VECTOR power;
	int FontHandle;
};

#endif // _PLAYER_H_