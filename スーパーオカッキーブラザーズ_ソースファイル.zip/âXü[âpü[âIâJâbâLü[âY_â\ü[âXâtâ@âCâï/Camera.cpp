﻿//-----------------------------------------------------------------------------
// @brief  カメラクラス.
// 2016 Takeru Yui All Rights Reserved.
//-----------------------------------------------------------------------------
#include "Camera.h"
#include"Player.h"

#define USE_LERP_CAMERA 0

//-----------------------------------------------------------------------------
// @brief  コンストラクタ.
//-----------------------------------------------------------------------------
Camera::Camera()
{
	//奥行0.1～1000までをカメラの描画範囲とする
	SetCameraNearFar(0.1f, 1000.0f);

	pos = VGet(0, 0, 0);
}

//-----------------------------------------------------------------------------
// @brief  デストラクタ.
//-----------------------------------------------------------------------------
Camera::~Camera()
{
	// 処理なし.
}
void Camera::Init()
{
	startTime = GetNowCount();
}
//-----------------------------------------------------------------------------
// @brief  更新.
// １３秒（回すのに１０秒、余韻３秒）たったら画面をお掃除する
//-----------------------------------------------------------------------------
void Camera::Update(VECTOR targetPos,Player* player)
{
	//clsDx();
	VECTOR m_pos = targetPos;
	float VRotate = 0.0f;
	float HRotate = 0.0f;
	float TRotate = 0.0f;
	
	pos = VGet(m_pos.x, m_pos.y + 50.0f, m_pos.z+1);
	nowTime = GetNowCount();
	if (player->GetTimer() == 600)
	{
		VRotate = 30.0f * DX_PI_F / 180;
		HRotate = 90.0f * DX_PI_F / 180;
	}
	else
	{
		VRotate = 90.0f * DX_PI_F / 180;
		HRotate = 180.0f * DX_PI_F / 180;
	}
	SetCameraPositionAndAngle(pos, VRotate,HRotate,TRotate);
	//printfDx("nowTime:%d",nowTime-startTime);
}