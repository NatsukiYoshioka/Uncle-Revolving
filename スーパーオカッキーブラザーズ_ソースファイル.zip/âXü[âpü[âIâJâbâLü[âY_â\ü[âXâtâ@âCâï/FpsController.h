#pragma once
class FpsController
{
public:
	FpsController();
	~FpsController(){}

	void Update();
	void Draw();
	void Wait();

private:
	int startTime;
	int Count;
	float Fps;
	const int N = 60;
	const int FPS = 60;
};