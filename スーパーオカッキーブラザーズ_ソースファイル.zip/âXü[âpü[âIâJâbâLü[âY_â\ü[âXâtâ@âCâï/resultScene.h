#pragma once
#include"SceneManager.h"

class SceneManager;
class resultScene
{
public:
	resultScene();
	~resultScene(){}

	void Update(SceneManager* manager);
	void Draw();
private:
	float score;
};

