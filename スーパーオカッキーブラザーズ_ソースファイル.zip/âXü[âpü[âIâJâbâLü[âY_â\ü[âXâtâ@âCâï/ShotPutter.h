#pragma once
#include"SceneManager.h"
#include"background.h"
#include"Score.h"
#include"Player.h"
#include"Animation.h"
#include"Camera.h"
#include"Map.h"

class SceneManager;
class background;
class Score;
class Player;
class Animation;
class Map;
class SoundBox;

class ShotPutter
{
public:
	ShotPutter();
	~ShotPutter();

	void Update(SceneManager* manager,SoundBox* sound,ShotPutter* inGame);
	void Draw();

	bool IsFlightSound = false;
private:
	background* Background;
	Score* score;
	Player* player;
	Animation* animation;
	Camera* camera;
	Map* map;
	int FontHandle;
};