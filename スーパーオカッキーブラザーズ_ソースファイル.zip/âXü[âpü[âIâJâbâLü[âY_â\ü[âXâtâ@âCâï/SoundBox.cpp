#include<DxLib.h>
#include"SoundBox.h"

SoundBox::SoundBox(void)
{
	GameStartSHandle = LoadSoundMem("Sound/GameStart.mp3");
	 TitleSHandle = LoadSoundMem("Sound/Title.mp3");
	 ResultSHandle = LoadSoundMem("Sound/Result.mp3");
	 SwingSHandle = LoadSoundMem("Sound/Swing.mp3");
	 HammerSelectSHandle= LoadSoundMem("Sound/HammerSelect.mp3");
	 RotateSHandle = LoadSoundMem("Sound/Rotate.mp3");
	 LandingSHandle = LoadSoundMem("Sound/Landing.mp3");
	 FlightSHandle = LoadSoundMem("Sound/Flight.mp3");
	 GameSelectSHandle = LoadSoundMem("Sound/Select.mp3");
	 GameBGMSHandle = LoadSoundMem("Sound/GameBGM.mp3");
	 UFOSHandle = LoadSoundMem("Sound/UFO.mp3");
	 SetCreateSoundTimeStretchRate(5.0f);
	 ScreamSHandle = LoadSoundMem("Sound/Scream.mp3");
}
SoundBox::~SoundBox(void)
{
	// �������ׂč폜���܂�
	InitSoundMem();
}


void SoundBox::play(int snum)
{
	PlaySoundMem(snum, DX_PLAYTYPE_BACK);
}
void SoundBox::playloop(int snum)
{
	PlaySoundMem(snum, DX_PLAYTYPE_LOOP, FALSE);
}
void SoundBox::stop(int snum)
{
	StopSoundMem(snum);
}

//void SoundBox::del(int snum)
//{
//	DeleteSoundMem(snum);
//}