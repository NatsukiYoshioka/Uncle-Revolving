#include "SceneManager.h"
#include "ShotPutter.h"
#include"SoundBox.h"

SceneManager::SceneManager() :nowScene(SCENE_MENU), nextScene(SCENE_NONE), MenuScene(0), GameScene(0), ResultScene(0),sound(0)
{
	MenuScene = new menuScene();
	GameScene = new ShotPutter();
	ResultScene = new resultScene();
	sound = new SoundBox();
}

SceneManager::~SceneManager()
{
	delete(sound);/*
	delete(MenuScene);*/
	delete(GameScene);
	delete(ResultScene);
}

//�V�[������
void SceneManager::Update(SceneManager* manager)
{
	//�V�[���̐؂�ւ�
	if (nextScene != SCENE_NONE)
	{
		Finalize();
		nowScene = nextScene;
		nextScene = SCENE_NONE;
		Init();
	}

	switch (nowScene)
	{
	case SCENE_MENU:
		MenuScene->Update(manager);
		break;
	case SCENE_GAME:
		GameScene->Update(manager,sound,GameScene);
		break;
	case SCENE_RESULT:
		ResultScene->Update(manager);
		break;
	}
}

//���݃V�[���̏�����
void SceneManager::Init()
{
	InitializeModule(nowScene);
}

void SceneManager::InitializeModule(int Scene)
{
	switch (Scene)
	{
	case SCENE_MENU:
		MenuScene = new menuScene();
		//�^�C�g��BGM
		sound->playloop(sound->GetTitleSHandle());
		break;
	case SCENE_GAME:
		sound->play(sound->GetGameStartSHandle());
		//�Q�[���X�^�[�g
		GameScene = new ShotPutter();
		// �Q�[��BGM���ʂ̐ݒ�
		ChangeVolumeSoundMem(255 * 50 / 100, sound->GetGameBGMSHandle());
		// ���[�v�ʒu�����̐擪����6�b��ɃZ�b�g����
		SetLoopPosSoundMem(6000, sound->GetGameBGMSHandle());
		//�Q�[��BGM�J�n
		sound->playloop(sound->GetGameBGMSHandle());
		break;
	case SCENE_RESULT:
		ResultScene = new resultScene();
		//���U���gBGM
		sound->playloop(sound->GetResultSHandle());
		break;
	}
}

//���݃V�[���̌�n��
void SceneManager::Finalize()
{
	FinalizeModule(nowScene);
}

void SceneManager::FinalizeModule(int Scene)
{
	switch (Scene)
	{
	case SCENE_MENU:
		delete(MenuScene);
		sound->stop(sound->GetTitleSHandle());
		break;
	case SCENE_GAME:
		delete(GameScene);
		//�Q�[��BGM�I��
		sound->stop(sound->GetGameBGMSHandle());
		break;
	case SCENE_RESULT:
		sound->stop(sound->GetResultSHandle());
		delete(ResultScene);
		break;
	}
}

//�V�[�����̕`��
void SceneManager::Draw()
{
	switch (nowScene)
	{
	case SCENE_MENU:
		MenuScene->Draw();
		break;
	case SCENE_GAME:
		GameScene->Draw();
		break;
	case SCENE_RESULT:
		ResultScene->Draw();
		break;
	}
}

//���݃V�[���̕ύX
void SceneManager::ChangeScene(int NextScene)
{
	nextScene = NextScene;
}