﻿//-----------------------------------------------------------------------------
// @brief  カメラクラス.
// 2016 Takeru Yui All Rights Reserved.
//-----------------------------------------------------------------------------
#ifndef _CAMERA_H_
#define _CAMERA_H_
//#define ON_TIMER 0x01
#include "DxLib.h"

class Player;

class Camera
{
public:
	Camera();							// コンストラクタ.
	~Camera();							// デストラクタ.

	void Init();						// 設定
	void Update(VECTOR mapPos,Player* player);	// 更新.

	// ポジションのgetter/setter.
	const VECTOR& GetPos() const { return pos; }

private:
	VECTOR	pos;			// ポジション.
	//時間関係
	int startTime = 0;
	int nowTime = 0;
	//unsigned char Flag = 0;
};

#endif // _CAMERA_H_