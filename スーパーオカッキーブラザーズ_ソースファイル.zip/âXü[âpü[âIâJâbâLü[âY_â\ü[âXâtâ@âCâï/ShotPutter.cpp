#include "ShotPutter.h"
#include"FpsController.h"
#include"Effect.h"
#include"SoundBox.h"
#include"DxLib.h"

ShotPutter::ShotPutter():Background(0),score(0),player(0),animation(0),camera(0),map(0)
{
	Background = new background();
	score = new Score();
	player = new Player();
	animation = new Animation();
	camera = new Camera();
	map = new Map();
	animation->InitSetting(player->modelHandle);
	//Effekseer������������
	Effect_Initialize(player->GetPos());
	FontHandle = CreateFontToHandle(NULL, 50, 6);
}

ShotPutter::~ShotPutter()
{
	delete(Background);
	delete(score);
	delete(player);
	delete(animation);
	delete(camera);
	delete(map);
	Effect_Finalize();
	DeleteFontToHandle(FontHandle);
}

//�C�ۓ����V�[���̐���
void ShotPutter::Update(SceneManager* manager,SoundBox* sound,ShotPutter* inGame)
{
	if (CheckHitKey(KEY_INPUT_S) != 0)
	{
		manager->ChangeScene(SCENE_RESULT);
	}

	camera->Update(player->GetPos(), player);
	
	if (!player->endFlg)
	{
		FpsController* fpscontroll = 0;
		fpscontroll = new FpsController();
		while (!player->endFlg)
		{
			
			fpscontroll->Update();
			animation->Update(2);
			camera->Update(player->GetPos(), player);
			player->Update(sound);
			if (player->endFlg == true)
			{
				player->endFlg = false;
				animation->flg = false;
				delete(fpscontroll);
				//ClearDrawScreen();
				break;
			}
			ClearDrawScreen();
			Background->Draw();
			map->Draw();
			animation->Draw();
			MV1DrawModel(player->hammerModelHandle);
			if (player -> hitMouseFlg == false)
			{
				int width = GetDrawStringWidthToHandle("���N���b�N�������Ȃ���}�E�X�𒆐S�����ɂ܂킹�I", 100, FontHandle);
				DrawStringToHandle(960 - width / 2, 540, "���N���b�N�������Ȃ���}�E�X�𒆐S�����ɂ܂킹�I", GetColor(255, 255, 255), FontHandle);
			}
			fpscontroll->Draw();
			fpscontroll->Wait();
			ScreenFlip();
		}
	}
	

	if (!player->endFlg)
	{
		// �Q�[��BGM���ʂ̐ݒ�
		ChangeVolumeSoundMem(255 * 30 / 100, sound->GetGameBGMSHandle());

		//��s���ʂ̐ݒ�
		ChangeVolumeSoundMem(255 * 100 / 100, sound->GetFlightSHandle());
		FpsController* fpscontroll = 0;
		fpscontroll = new FpsController();
		int Count = 0;
		MV1SetRotationXYZ(player->modelHandle, VGet(0.0f, 0.0f, 0.0f));
		while (Count < 80)
		{
			fpscontroll->Update();
			animation->Update(1);
			Count++;
			ClearDrawScreen();
			Background->Draw();
			map->Draw();
			animation->Draw();
			fpscontroll->Draw();
			fpscontroll->Wait();
			ScreenFlip();
			if (Count == 80)
			{
				delete(fpscontroll);
				break;
			}
		}
		animation->Detach(player->modelHandle);
	}

	if (!player->endFlg)
	{
		FpsController* fpscontroll = 0;
		fpscontroll = new FpsController();
		while (!player->endFlg)
		{
			if (!inGame->IsFlightSound)
			{
				//��s
				sound->play(sound->GetScreamSHandle());
				
				sound->play(sound->GetFlightSHandle());
				inGame->IsFlightSound = true;
			}
			fpscontroll->Update();
			Effect_Update(player->GetPos(),player);
			player->Throw(map);
			if (player->endFlg)
			{
				delete(fpscontroll);
				sound->stop(sound->GetScreamSHandle());
				//���n
				sound->play(sound->GetLandingSHandle());
				break;
			}
			ClearDrawScreen();
			Background->Draw();
			player->Draw();
			Effect_Draw();
			score->GetScore(player);		//�X�R�A�擾
			if (score->GetScore() > 0)
			{
				//�w�i�̃X�N���[��
				Background->Update(player);
			}
			score->Draw();
			fpscontroll->Draw();
			fpscontroll->Wait();
			ScreenFlip();
		}
	}
	sound->stop(sound->GetFlightSHandle());

	
}

void ShotPutter::Draw()
{
	Background->Draw();				//�w�i�`��
	map->Draw();
	player->Draw();
	//score->GetScore(player);		//�X�R�A�擾
	score->Draw();					//�X�R�A�`��
	DrawFormatString(10, 30, GetColor(255, 255, 255), "InGAME");
}